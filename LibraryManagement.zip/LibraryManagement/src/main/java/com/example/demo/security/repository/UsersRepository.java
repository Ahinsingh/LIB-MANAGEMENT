package com.example.demo.security.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.admin.model.User;


public interface UsersRepository extends JpaRepository<User, Integer> {
    User findByUserName(final String email);
}

