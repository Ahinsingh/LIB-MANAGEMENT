package com.example.demo.admin.model;


import java.io.Serializable;
import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "BOOK")
public class Book implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="BOOK_ID")
	private Long bookId;
	
	@Column(name="BOOK_NAME")
	private String bookName;
	
	@Column(name="AUTHOR_NAME")
	private String authorName;
	
	@Column(name="QUANTITY")
	private Long quantity;
	
	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	private ZonedDateTime createdOn;
	
	@Column(name = "PUBLISHER_NAME")
	private String publisherName;
	
	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_ON")
	private ZonedDateTime updatedOn;
	
	
}
