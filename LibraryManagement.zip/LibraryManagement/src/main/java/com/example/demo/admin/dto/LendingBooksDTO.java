package com.example.demo.admin.dto;


import java.time.ZonedDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
	public class LendingBooksDTO {
		
	private Long bookId;
	
	private String bookName;
	
	private String authorName;
	
	private Long quantity;
	
	private String createdBy;

	private ZonedDateTime createdOn;
	
	private String publisherName;
	
	private String category;

	private String updatedBy;

	private ZonedDateTime updatedOn;
}
