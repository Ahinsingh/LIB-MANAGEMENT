package com.example.demo.admin.service;


import java.util.List;

import com.example.demo.admin.dto.UserDTO;
import com.example.demo.admin.model.User;

public interface UserMgmtService {

    public List<UserDTO> listAllUsers();

    public String addUser(User user);

    public String editUserDetails(User user);

    public String deleteUser(Long userId);

    public UserDTO getUserDetails(String userId);

	public String updateUserDetails(User userData);

	public String bookLending(User user);

	public List<UserDTO> listAllNormalUsers();

	public List<UserDTO> listAllLendingUsers();

}
