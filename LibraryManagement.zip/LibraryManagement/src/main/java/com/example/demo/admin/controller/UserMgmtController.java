package com.example.demo.admin.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.admin.dto.UserDTO;
import com.example.demo.admin.model.User;
import com.example.demo.admin.service.UserMgmtService;

import lombok.AllArgsConstructor;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/v1/api/usermgmt")
@AllArgsConstructor
public class UserMgmtController {
	private final Logger adminActivity = LoggerFactory.getLogger("adminActivityLog");
	
	@Autowired
	private UserMgmtService userMgmtService;
	
	@PostMapping(value = "/addUser" )
	public ResponseEntity<?> addUser(@RequestBody User user) {
		String res=userMgmtService.addUser(user);
		return ResponseEntity.ok()
			    .body(res);
	}
	
	@PostMapping(value = "/bookLending" )
	public ResponseEntity<?> bookLending(@RequestBody User user) {
		String res=userMgmtService.bookLending(user);
		return ResponseEntity.ok()
			    .body(res);
	}
	
	
	
	@GetMapping(value = "/listAllUsers")
	public List<UserDTO> listAllUsers() {
		adminActivity.debug("Load All Users");
		List<UserDTO> roleList = userMgmtService.listAllUsers();
		return roleList;
	}
	
	@GetMapping(value = "/listAllNormalUsers")
	public List<UserDTO> listAllNormalUsers() {
		adminActivity.debug("All Normal Users");
		List<UserDTO> roleList = userMgmtService.listAllNormalUsers();
		return roleList;
	}
	
	
	@GetMapping(value = "/listAllLendingUsers")
	public List<UserDTO> listAllLendingUsers() {
		List<UserDTO> roleList = userMgmtService.listAllLendingUsers();
		return roleList;
	}
	
	
	@DeleteMapping(value = "/deleteUser/{userID}")
	public ResponseEntity<?> deleteUserRole(@PathVariable Long userID) {
		String res=userMgmtService.deleteUser(userID);
		return ResponseEntity.ok()
	    .body(res);
	}
	
	@GetMapping(value = "/getUserDetails/{userId}")
	public UserDTO getUserDetails(@PathVariable String userId) {
		UserDTO user=userMgmtService.getUserDetails(userId);
		return user;
		 
	}
	
	@PutMapping(value = "/updateUser")
	public ResponseEntity<?> updateUser(@RequestBody User userData) {
		String res= userMgmtService.updateUserDetails(userData);
		return ResponseEntity.ok().body(res);
	}
	
}
