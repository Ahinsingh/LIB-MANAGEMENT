package com.example.demo.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.admin.dao.UserRepository;
import com.example.demo.admin.model.User;



@Service
public class JwtUserDetailsService {
		
	    @Autowired
		private UserRepository userDao;		

		public User loadUserByUsername(String username) throws UsernameNotFoundException {
			User user = userDao.findByUserName(username).orElse(null);
			if (user == null) {
				throw new UsernameNotFoundException("User not found with username: " + username);
			}
			return user;
		}


}
