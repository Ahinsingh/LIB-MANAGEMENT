package com.example.demo.admin.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.admin.model.Book;
import com.example.demo.admin.service.BookMgmtService;
import com.example.demo.api.ApiResponse;

import lombok.AllArgsConstructor;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/v1/api/booksmgmt")
@AllArgsConstructor
public class BookMgmtController {

	@Autowired
	private BookMgmtService bookService;
	
	@PostMapping(value = "/addBook" )
	public ResponseEntity<?> addBook(@RequestBody Book bookData) {
		String res=bookService.addBook(bookData);
		return ResponseEntity.ok()
			    .body(res);
	}
	
	@GetMapping(value = "/listAllBooks")
	public  ResponseEntity<?>  listAllBooks() {
		List<Book> booksList = bookService.listAllBooks();
		ApiResponse response = new ApiResponse();
		response.setStatus(200);
		response.setMessage("SUCCESS");
		response.setData(booksList);
		return ResponseEntity.ok()
				//.header("Access-Control-Allow-Origin", "*")
			    .body(response);
	}
	
	@DeleteMapping(value = "/deleteBook/{bookNo}")
	public ResponseEntity<?> deleteBookRole(@PathVariable Long bookNo) {
		String res=bookService.deleteBook(bookNo);
		return ResponseEntity.ok()
	    .body(res);
	}
	
	@GetMapping(value = "/books/{bookNo}")
	public ResponseEntity<?> getBookDetails(@PathVariable Long bookNo) {
		Book book= bookService.getBookDetails(bookNo);
		return ResponseEntity.ok()
			//	.header("Access-Control-Allow-Origin", "*")
			    .body(book);
	}
}
