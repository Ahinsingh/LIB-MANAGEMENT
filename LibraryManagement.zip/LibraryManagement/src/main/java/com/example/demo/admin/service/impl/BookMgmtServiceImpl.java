package com.example.demo.admin.service.impl;


import java.time.ZonedDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.admin.dao.BookRepository;
import com.example.demo.admin.model.Book;
import com.example.demo.admin.service.BookMgmtService;

import lombok.AllArgsConstructor;

@Transactional
@Service
@AllArgsConstructor
public class BookMgmtServiceImpl implements BookMgmtService{

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public String addBook(Book book) {
		Book bookDtls1 = bookRepository.findByBookId(book.getBookId());
		if (bookDtls1 != null) {
			return "Book Exist already";
		}
		ZonedDateTime now =ZonedDateTime.now();
		book.setUpdatedOn(now);
		book.setCreatedOn(now);
		Book bookDtls = bookRepository.save(book);
		return "Book Added Successfully";
	}

	@Override
	public List<Book> listAllBooks() {
		List<Book> bookList = bookRepository.findAll();
		return bookList;
	}

	@Override
	public String deleteBook(Long bookNo) {
		Book bookDtls = bookRepository.findByBookId(bookNo);
		bookRepository.delete(bookDtls);
		return "Delete Success";
	}

	@Override
	public Book getBookDetails(Long bookNo) {
		Book userDtls = bookRepository.findByBookId(bookNo);
		return userDtls;
	}

}
