package com.example.demo.admin.service.impl;


import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.admin.dao.BookRepository;
import com.example.demo.admin.dao.LendingRepository;
import com.example.demo.admin.dao.UserRepository;
import com.example.demo.admin.dto.UserDTO;
import com.example.demo.admin.model.Book;
import com.example.demo.admin.model.LendingBooks;
import com.example.demo.admin.model.User;
import com.example.demo.admin.service.UserMgmtService;
import com.example.demo.admin.dto.LendingBooksDTO;

import lombok.AllArgsConstructor;

@Transactional
@Service
@AllArgsConstructor
public class UserMgmtServiceImpl implements UserMgmtService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private LendingRepository lendingBookRepository;
	

	public List<UserDTO> listAllUsers() {
		List<User> userList = userRepository.findAll();
		
		List<UserDTO> listDto=new ArrayList<>();
		userList.forEach(obj->{
			UserDTO dto=new UserDTO();
			dto.setUserId(obj.getUserId());
			dto.setUserName(obj.getUserName());
			dto.setRole(obj.getRole());
			listDto.add(dto);
		});
		
		return listDto;
	}

	@Override
	public String addUser(User user) {
		User userDtls1 = userRepository.findByUserName(user.getUserName()).orElse(null);
		if (userDtls1 != null) {
			return "User Exist already";
		}
		ZonedDateTime now =ZonedDateTime.now();
		user.setIsActive(1);
		user.setUpdatedOn(now);
		user.setCreatedOn(now);
		User userDtls = userRepository.save(user);
		return "User Added Successfully";
	}

	
	@Override
	public String deleteUser(Long userId) {
		User userDtls = userRepository.findByUserId(userId).get();
		userRepository.delete(userDtls);
		return "Delete Success";
	}

	@Override
	public UserDTO getUserDetails(String userId) {
	//	User userDtls = userRepository.findByUserId(userId).get();
		try {
			User userDtls = userRepository.findByUserName(userId).get();
			UserDTO user= new UserDTO();
			user.setUserName(userDtls.getUserName());
			user.setUserId(userDtls.getUserId());
			user.setRole(userDtls.getRole());
			return user;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public String editUserDetails(User user) {
	
		return null;
	}

	@Override
	public String updateUserDetails(User userData) {
		
		User userDtls = userRepository.findByUserId(userData.getUserId()).get();
		userDtls.setIsActive(userData.getIsActive());
		userDtls.setUserName(userData.getUserName());
		userDtls.setUpdatedBy(userData.getUpdatedBy());
		userDtls.setUpdatedOn(ZonedDateTime.now());
		
		userRepository.save(userDtls);
		return "User Details has been updated successfully";
	}

	@Override
	public String bookLending(User user) {
	  User userDtls1 = userRepository.findByUserId(user.getUserId()).orElse(null);
	  List<LendingBooks> taken =userDtls1.getBooks();
	    LendingBooks book = new LendingBooks();
	    Book bookObj = new Book();
	    List<LendingBooks> books=new ArrayList<>();
	    books = user.getBooks();
	    book = books.get(0);
	    
	    List<String> bookNamesArr= new ArrayList<>();
	    
	    taken.forEach(obj->{
	    	bookNamesArr.add(obj.getBookName());
	    });
	    bookObj=bookRepository.findByBookId(book.getBookId());
	    if(!bookNamesArr.contains(book.getBookName())) {
	    	Long quantity = bookObj.getQuantity();
		    bookObj.setQuantity(quantity-1);
		    bookRepository.save(bookObj);
			ZonedDateTime now =ZonedDateTime.now();
			book.setCreatedOn(now);
			book.setUpdatedOn(now);
			book.setUser(userDtls1);
			book.setBookName(bookObj.getBookName());
			book.setAuthorName(bookObj.getAuthorName());
			book.setBookId(bookObj.getBookId());
			book.setCategory(bookObj.getCategory());
			lendingBookRepository.save(book);
			return "Book is Added to "+ userDtls1.getUserName();
	    }else {
	    	return "This Book is Already taken by  "+ userDtls1.getUserName();
	    }
	    
	}

	@Override
	public List<UserDTO> listAllNormalUsers() {
		List<User> userList = userRepository.findAllByRole("USER");
		
		List<UserDTO> listDto=new ArrayList<>();
		userList.forEach(obj->{
			UserDTO dto=new UserDTO();
			dto.setUserId(obj.getUserId());
			dto.setUserName(obj.getUserName());
			listDto.add(dto);
		});
		
		return listDto;
	}

	@Override
	public List<UserDTO> listAllLendingUsers() {
		List<User> userList = userRepository.findAllByRole("USER");
		
		List<UserDTO> listDto=new ArrayList<>();
		userList.forEach(obj->{
			List<LendingBooks> lendingBooks = new ArrayList<>();
			lendingBooks=obj.getBooks();
			if(!lendingBooks.isEmpty()) {
			UserDTO dto=new UserDTO();
			dto.setUserId(obj.getUserId());
			dto.setUserName(obj.getUserName());
			List<LendingBooksDTO> dtoList = new ArrayList<>();
			
			
			lendingBooks.forEach(book->{
				LendingBooksDTO bookDto = new LendingBooksDTO();
				bookDto.setAuthorName(book.getAuthorName());
				bookDto.setBookId(book.getBookId());
				bookDto.setBookName(book.getBookName());
				bookDto.setPublisherName(book.getPublisherName());
				dtoList.add(bookDto);
			});
			listDto.add(dto);
			dto.setBooks(dtoList);
		   }
		});
		
		return listDto;
	}

}
