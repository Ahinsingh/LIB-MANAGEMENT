package com.example.demo.admin.service;


import java.util.List;

import com.example.demo.admin.model.Book;

public interface BookMgmtService {

	String addBook(Book bookData);

	List<Book> listAllBooks();

	String deleteBook(Long bookNo);

	Book getBookDetails(Long bookNo);

}
