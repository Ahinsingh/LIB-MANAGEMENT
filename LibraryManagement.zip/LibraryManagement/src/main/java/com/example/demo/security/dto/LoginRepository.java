package com.example.demo.security.dto;


import org.springframework.data.repository.CrudRepository;

import com.example.demo.admin.model.User;


public interface LoginRepository extends CrudRepository<User, Integer> {
	//User loadUserByStaffID(String username);
}
