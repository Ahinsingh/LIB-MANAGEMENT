package com.example.demo.admin.dto;


import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class UserDTO {
	 private Long userId;
	 private String userName;
	 private String password;
	 private String role;
	 private List<LendingBooksDTO> books;
}
