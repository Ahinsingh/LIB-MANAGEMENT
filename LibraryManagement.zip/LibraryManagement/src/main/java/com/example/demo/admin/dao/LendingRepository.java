package com.example.demo.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.admin.model.LendingBooks;

public interface LendingRepository extends JpaRepository<LendingBooks, String> {

}
