class Constants {
    
}

 export const API = "http://127.0.0.1:8080/v1/api";

export const HIGHTLIGHT_JOB_CELL = {
  3: "alert-success"
};

export default Constants;