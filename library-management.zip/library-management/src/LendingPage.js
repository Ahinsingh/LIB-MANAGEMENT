import React, { Component } from 'react'
import Header from './Header'
import * as Constants from './Constants';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sort from '../src/Icons/sort.png'
import axios from 'axios'
import SearchInput, { createFilter } from 'react-search-input'
import Edit from '../src/Icons/eswjc icons/edit.png'
import Close from '../src/Icons/eswjc icons/close-yellow.png'


class LendingPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            authStr: 'Bearer ' + JSON.parse(localStorage.getItem('token')),
            userId: "", userName: "",
            staffID:"select",
            userId: localStorage.getItem('userId'),
            userList: [],
             staffList: [], addUserRoleList: [], visible: false,roleList: [],
             bookName:"",bookId:0,
             lendingUserList:[],
             addedBookList:[],
             bookId:0
        }
    }

    async getAddUserList() {
        axios.get(Constants.API + "/usermgmt/listAllNormalUsers", { 'headers': { 'Authorization': this.state.authStr } })
            .then(result => {
                this.setState({
                    userList: result.data
                });
            })
            .catch(error => this.setState({
                error,
                loading: false
            }));
    }

    async getAddBookList() {
        axios.get(Constants.API + "/booksmgmt/listAllBooks", { 'headers': { 'Authorization': this.state.authStr } })
            .then(result => {
                this.setState({
                    addedBookList: result.data.data
                });
            })
            .catch(error => this.setState({
                error,
                loading: false
            }));
    }

    componentDidMount() {
        this.getAddUserList();
        this.listAllLendingUsers();
        this.getAddBookList();
    }

    async listAllLendingUsers() {
        axios.get(Constants.API + "/usermgmt/listAllLendingUsers", { 'headers': { 'Authorization': this.state.authStr } })
            .then(result => {
                this.setState({
                    lendingUserList: result.data
                });
            })
            .catch(error => this.setState({
                error,
                loading: false
            }));
    }

    handleChangeUserName(e) {
        this.setState({ 
            userName: e.target.value
        })
    }

     handleChangeStaffID = (e) => {
        this.setState({
            userId: e.target.value
        })
    }

    handleChangeBookId= (e) => {
      
        this.setState({
            bookId: e.target.value
        })
    }

    lendingBooks = event => {
        let user = {
            userId: this.state.userId ? this.state.userId : '',
            books:[{
                bookId: this.state.bookId ? this.state.bookId : 0,
                bookName: this.state.bookName ? this.state.bookName : '',
            }]
        }
        axios.post(Constants.API + "/usermgmt/bookLending", user, { 'headers': { 'Authorization': this.state.authStr } }).then(result => {
            if (result.data) {
                toast(result.data);
            }
        })
        .catch(error => this.setState({
            error,
            loading: false
        }));
       
        

    }

    render(props) {
        return (
            <div>
                 <ToastContainer />
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Add New Users</h5>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-lg-12 row">
                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Staff ID </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <select style={{ height: "30px", width: "160px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px" }} onChange={(e) => this.handleChangeStaffID(e)} value={this.state.userId}>
                                                <option>Select</option>
                                                {this.state.userList.map((record, index) => {
                                                    return (
                                                        <option value={record.userId}>{record.userName}</option>
                                                    )
                                                })}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Book Name</label>
                                        </div>
                                       <div class="col-lg-6">
                                            <select style={{ height: "30px", width: "160px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px" }} onChange={(e) => this.handleChangeBookId(e)} value={this.state.book}>
                                                <option >Select</option>
                                                {this.state.addedBookList.map((record, index) => {
                                                    return (
                                                        <option value={record.bookId}>{record.bookName}</option>
                                                    )
                                                })}
                                                
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                        </div>
                                        <div class="col-lg-6">
                                            <button style={{ height: "30px", width: "85px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={this.lendingBooks}>Add </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Users List</h5>
                </div>
                <br></br>
                <div class="col-lg-12 row">
                    <div class="col-lg-8">
                    </div>
                    <div class="col-lg-4">
                        <div class="col-lg-12 row">
                            <div class="col-lg-3">
                                <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Search </label>
                            </div>
                            <div class="col-lg-3">
                                <SearchInput className="search-input" onChange={this.searchUpdated} />
                            </div>
                            <div class="col-lg-6">
                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div class="table-responsive">
                    <table className="table">
                        <thead style={{ height: "40px", backgroundColor: "#52627f" }}>
                            <tr>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>User Id<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>User Name<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Created Date<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}></th>
                            </tr>
                        </thead>
                        <tbody style={{ backgroundColor: "#ffffff" }}>
                            {this.state.lendingUserList && this.state.lendingUserList.map((item, index) => {
                                return (
                                    <tr key={index}>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.userId}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.userName}</td>



                                     <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>
                                    {item && item.books.map((book, index) => {
                                        return (
                                            <div>
                                                <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>{book.bookName} </label>
                                                <br></br>
                                            </div>
                                        )
                                    })}
                                    
                                </td>
                            </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}
export default LendingPage;