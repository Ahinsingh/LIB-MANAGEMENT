import React, { Component } from 'react'
import * as Constants from './Constants';
import Sort from '../src/Icons/sort.png'
import axios from 'axios'
import SearchInput, { createFilter } from 'react-search-input'
import Edit from '../src/Icons/eswjc icons/edit.png'
import Close from '../src/Icons/eswjc icons/close-yellow.png'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class AddBook extends Component {
    constructor(props) {
        super(props);
        this.state = {
            authStr: 'Bearer ' + JSON.parse(localStorage.getItem('token')),
            bookId:0,
            bookName:"",
            authorName:"",
            quantity:0,
            addUserList:[],
            category:""
        }
    }
    async getAddBookList() {
        axios.get(Constants.API + "/booksmgmt/listAllBooks", { 'headers': { 'Authorization': this.state.authStr } })
            .then(result => {
                this.setState({
                    addUserList: result.data.data
                });
            })
            .catch(error => this.setState({
                error,
                loading: false
            }));
    }
    handleChangeBookId(e) {
        this.setState({
            bookId: e.target.value
        })
    }

    handleChangeBookName(e) {
        this.setState({
            bookName: e.target.value
        })
    }

    handleChangeAuthorName(e) {
        this.setState({
            authorName: e.target.value
        })
    }

    handleChangeQuantity(e) {
        this.setState({
            quantity: e.target.value
        })
    }

    handleChangeCategory(e) {
        this.setState({
            category: e.target.value
        })
    }

    addBook = event => {
        let book = {
           // bookId: this.state.bookId ? this.state.bookId : '',
            bookName: this.state.bookName ? this.state.bookName : '',
            authorName : this.state.authorName ? this.state.authorName : '',
            quantity : this.state.quantity ? this.state.quantity :0,
            category:this.state.category ? this.state.category :''
        }
        axios.post(Constants.API + "/booksmgmt/addBook", book, { 'headers': { 'Authorization': this.state.authStr } })
        .then(result => {
            if (result.data) {
                toast(result.data);
            }
        })
        .catch(error => this.setState({
            error,
            loading: false
        }));
    }

    componentDidMount() {
        this.getAddBookList();
    }
    render(props) {
        return (
            <div>
                <ToastContainer />
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Add New Books</h5>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-lg-12 row">
                                {/* <div class="col-lg-4">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Book Number </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                            value={this.state.bookId} onChange={(e) => this.handleChangeBookId(e)}>
                                            </input>
                                        </div>
                                    </div>
                                </div> */}
                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Book Name</label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                            value={this.state.bookName} onChange={(e) => this.handleChangeBookName(e)}>
                                            </input>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Author Name</label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                            value={this.state.authorName} onChange={(e) => this.handleChangeAuthorName(e)}>
                                            </input>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Quantity</label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                            value={this.state.quantity} onChange={(e) => this.handleChangeQuantity(e)}>
                                            </input>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Category</label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                            value={this.state.category} onChange={(e) => this.handleChangeCategory(e)}>
                                            </input>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-2">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                        </div>
                                        <div class="col-lg-6">
                                            <button style={{ height: "30px", width: "85px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={this.addBook}>Add Book</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Books  List</h5>
                </div>
                <br></br>
                <div class="col-lg-12 row">
                    <div class="col-lg-8">
                    </div>
                    <div class="col-lg-4">
                        <div class="col-lg-12 row">
                            <div class="col-lg-3">
                                <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Search </label>
                            </div>
                            <div class="col-lg-3">
                                <SearchInput className="search-input" onChange={this.searchUpdated} />
                            </div>
                            <div class="col-lg-6">
                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div class="table-responsive">
                    <table className="table">
                        <thead style={{ height: "40px", backgroundColor: "#52627f" }}>
                            <tr>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Book Id<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Book Name<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Author Name<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Quantity<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}></th>
                            </tr>
                        </thead>





                        <tbody style={{ backgroundColor: "#ffffff" }}>
                            {this.state.addUserList.map((item, index) => {
                                return (
                                    <tr key={index}>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.bookId}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.bookName}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.authorName}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.quantity}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>
                                            <div class="col-lg-12 row">
                                                <div class="col-lg-6">
                                                    <img src={Edit} alt={"Edit"}></img>
                                                </div>
                                                <div class="col-lg-6">
                                                    <img src={Close} alt={"Close"}></img>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div >
        );
    }
}
export default AddBook;