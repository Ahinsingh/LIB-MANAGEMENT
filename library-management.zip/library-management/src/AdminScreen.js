import React, { Component } from 'react'
import Header from './Header'
import * as Constants from './Constants';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sort from '../src/Icons/sort.png'
import axios from 'axios'
import SearchInput, { createFilter } from 'react-search-input'
import Edit from '../src/Icons/eswjc icons/edit.png'
import Close from '../src/Icons/eswjc icons/close-yellow.png'
import AddBook from './AddBook'
import AddUser from './AddUser'
 import LendingPage from './LendingPage'

class AdminScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            authStr: 'Bearer ' + JSON.parse(localStorage.getItem('token')),
            visible: "UserVisible"
        }
    }

    componentDidMount() {

    }

    visibleStatus = (event, status) => {
        this.setState({
            visible: status,
        });
    }

    render(props) {
        return (
            <div>
                <Header />
                <ToastContainer />
                < div class="col-lg-12" style={{ paddingTop: "22px", backgroundColor: "#e8ecf4" }}>
                    <div class="col-lg-12 row">
                        <div class="col-lg-3">
                            <h2 style={{ color: "#002c70" }}> ADMIN</h2>
                        </div>
                        <div class="col-lg-9">
                        </div>
                    </div>
                    <div class="col-lg-12 row">
                        <div class="col-lg-2" style={{ borderTop: "3px solid #002c70" }}>
                        </div>
                        <div class="col-lg-10">
                        </div>
                    </div>
                    <br></br>
                   
                    {this.state.visible == "BookVisible" ?
                        <div class="btn-group">
                            <button style={{ height: "30px", backgroundColor: "#ffffff", borderRadius: "4px", color: "#002c70", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "BookVisible")}>Add Books</button>
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "UserVisible")}>Add Users</button>
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "LendBookToUser")}>Lend Book To User</button>
                        </div>
                        : <></>}
                    {this.state.visible == "UserVisible" ?
                        <div class="btn-group">
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "BookVisible")}>Add Books</button>
                            <button style={{ height: "30px", backgroundColor: "#ffffff", borderRadius: "4px", color: "#002c70", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "UserVisible")}>Add Users</button>
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "LendBookToUser")}>Lend Book To User</button>
                        </div>
                        : <></>}
                         {this.state.visible == "LendBookToUser" ?
                        <div class="btn-group">
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "BookVisible")}>Add Books</button>
                            <button style={{ height: "30px", backgroundColor: "#ffffff", borderRadius: "4px", color: "#002c70", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "UserVisible")}>Add Users</button>
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.visibleStatus(e, "LendBookToUser")}>Lend Book To User</button>
                        </div>
                        : <></>}
                    <br></br>
                    <br></br>
                    {this.state.visible == "UserVisible" ?
                        <>
                            <AddUser />
                        </>
                        : <></>
                    }
                   
                    {this.state.visible == "BookVisible" ?
                        <>
                            <AddBook />
                        </>
                        : <></>
                    }

                     {this.state.visible == "LendBookToUser" ?
                        <>
                             <LendingPage /> 
                        </>
                        : <></>
                    }
                   
                </div>
            </div>
        );
    }
}
export default AdminScreen;