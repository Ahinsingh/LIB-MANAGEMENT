import React, { Component } from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import LoginPage from "./components/LoginPage";
import AdminScreen from "./AdminScreen"
class App extends Component {

    render() {
        return (
            <BrowserRouter forceRefresh={true}>
                <div>
                    <Switch>
                        <Route path="/admin" exact component={AdminScreen}></Route>
                        <Route path="/login" component={LoginPage}></Route>
                        <Route component={Error} />
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}

export default App;