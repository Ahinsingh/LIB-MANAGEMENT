import React, { Component } from 'react'
import Header from './Header'
import * as Constants from './Constants';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios'
import SearchInput, { createFilter } from 'react-search-input'
import Edit from '../src/Icons/eswjc icons/edit.png'
import Close from '../src/Icons/eswjc icons/close-yellow.png'
import { Table, Popconfirm, Modal, Button, Space, Input } from 'antd';
import 'antd/dist/antd.css'
import { SearchOutlined } from '@ant-design/icons';
import Highlighter from 'react-highlight-words'

class AddUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            authStr: 'Bearer ' + JSON.parse(localStorage.getItem('token')),
            userId: "", userName: "",
            userId: localStorage.getItem('userId'),
           // userName: localStorage.getItem('userName'),
            role:"",
            addUserList: [],
            password : "",
            searchVal:"", searchText: '', searchedColumn: ''
        }
    }

    componentDidMount() {
        this.getAddUserList();
    }

    async getAddUserList() {
        axios.get(Constants.API + "/usermgmt/listAllUsers", { 'headers': { 'Authorization': this.state.authStr } })
            .then(result => {
                this.setState({
                    addUserList: result.data
                });
            })
            .catch(error => this.setState({
                error,
                loading: false
            }));
    }

    handleChangeUserName(e) {
        this.setState({
            userName: e.target.value
        })
    }

    handleChangeUserId(e) {
        this.setState({
            userId: e.target.value
        })
    }

    handleChangeRole(e) {
        this.setState({
            role: e.target.value
        })
    }

    handleChangePassword(e) {
        this.setState({
            password: e.target.value
        })
    }
    deleteUser= (event, user) => {
        axios.delete(Constants.API + "/usermgmt/deleteUser/"+user.userId, { 'headers': { 'Authorization': this.state.authStr } })
        .then(result => {
            if (result.data) {
                toast(result.data);
            }
        })
        .catch(error => this.setState({
            error,
            loading: false
        }));
    }
    addUser = event => {
        let user = {
         //   userId: this.state.userId ? this.state.userId : 0,
            userName: this.state.userName ? this.state.userName : '',
            password: this.state.password ? this.state.password : '',
            role: this.state.role ? this.state.role : '',
        }
         axios.post(Constants.API + "/usermgmt/addUser", user, { 'headers': { 'Authorization': this.state.authStr } })
        .then(result => {
            if (result.data) {
                toast(result.data);
            }
        })
        .catch(error => this.setState({
            error,
            loading: false
        }));

    }

    getColumnSearchProps = dataIndex => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div style={{ padding: 8 }}>
                <Input
                    ref={node => {
                        this.searchInput = node;
                    }}
                    placeholder={`Search ${dataIndex}`}
                    value={selectedKeys[0]}
                    onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                    style={{ width: 188, marginBottom: 8, display: 'block' }}
                />
                <Space>
                    <Button
                        type="primary"
                        onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                        icon={<SearchOutlined />}
                        size="small"
                        style={{ width: 90 }}
                    >
                        Search
              </Button>
                    <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{ width: 90 }}>
                        Reset
              </Button>
                </Space>
            </div>
        ),
        filterIcon: filtered => <SearchOutlined style={{ color: filtered ? '#1890ff' : undefined }} />,
        onFilter: (value, record) =>
            record[dataIndex]
                ? record[dataIndex].toString().toLowerCase().includes(value.toLowerCase())
                : '',
        onFilterDropdownVisibleChange: visible => {
            if (visible) {
                setTimeout(() => this.searchInput.select(), 100);
            }
        },
        render: text =>
            this.state.searchedColumn === dataIndex ? (
                <Highlighter
                    highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
                    searchWords={[this.state.searchText]}
                    autoEscape
                    textToHighlight={text ? text.toString() : ''}
                />
            ) : (
                    text
                ),
    });

    handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        this.setState({
            searchText: selectedKeys[0],
            searchedColumn: dataIndex,
        });
    };

    handleReset = clearFilters => {
        clearFilters();
        this.setState({ searchText: '' });
    }

    render(props) {


        const columns = [
            {
                title: 'USER ID',
                dataIndex: 'userId',
                key: 'userId',
                sortDirections: ['descend', 'ascend'],
                sorter: (a, b) => a.userId.localeCompare(b.userId),
                ...this.getColumnSearchProps('userId'),
            }
            , {
                title: 'USER NAME',
                dataIndex: 'userName',
                key: 'userName',
                sortDirections: ['descend', 'ascend'],
                sorter: (a, b) => a.userName.localeCompare(b.userName),
                ...this.getColumnSearchProps('userName'),
            },
            {
                title: 'ROLE',
                dataIndex: 'role',
                key: 'role',
                sortDirections: ['descend', 'ascend'],
                sorter: (a, b) => a.role.localeCompare(b.role),
                ...this.getColumnSearchProps('role'),
            },
            {
                title: '',
                dataIndex: '',
                key: '',
                render: (text, record) => {
                    return (
                        <div class="col-lg-12 row">
                           
                            <div class="col-lg-6">
                                <Popconfirm title="Sure to delete?" onConfirm={(e) => this.handleDelete(e, record)}>
                                    <img src={Close} alt={"Close"}></img>
                                </Popconfirm>
                            </div>
                        </div>
                    )
                }
            }
        ]


        return (
            <div>
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Add New Users</h5>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-lg-12 row">
                            <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>User Name </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                                value={this.state.userName} onChange={(e) => this.handleChangeUserName(e)} >
                                            </input>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Password </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                                value={this.state.password} onChange={(e) => this.handleChangePassword(e)} >
                                            </input>
                                        </div>
                                    </div>
                                </div>

                              
                                <div class="col-lg-3">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Role Name </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input style={{ height: "30px", width: "140px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px", marginLeft: "12px" }} type='text'
                                                value={this.state.role} onChange={(e) => this.handleChangeRole(e)} >
                                            </input>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="col-lg-12 row">
                                        <div class="col-lg-6">
                                        </div>
                                        <div class="col-lg-6">
                                            <button style={{ height: "30px", width: "85px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={this.addUser}>Add </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div class="col-lg-12 row">
                    <h5 style={{ color: "#002c70" }}>Users List</h5>
                </div>
                <br></br>
                <div>
                    <Table
                        scroll={{ x: 800 }}
                        dataSource={this.state.addUserList}
                        columns={columns}
                        pagination={{
                            pageSizeOptions: ['10', '20', '30'],
                            showSizeChanger: true,
                            position: 'both',
                            total: this.state.addUserList.length,
                            defaultPageSize: 10,
                        }}
                    />
                </div>


                {/* <div class="table-responsive">
                    <table className="table">
                        <thead style={{ height: "40px", backgroundColor: "#52627f" }}>
                            <tr>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>User Id<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>User Name<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}>Created Date<img style={{ paddingLeft: "6px" }} src={Sort} alt={"Sort"}></img></th>
                                <th style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", textAlign: "center" }}></th>
                            </tr>
                        </thead>
                        <tbody style={{ backgroundColor: "#ffffff" }}>
                            {this.state.addUserList.map((item, index) => {
                                return (
                                    <tr key={index}>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.userId}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.userName}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>{item.createdDate}</td>
                                        <td style={{ fontFamily: "roboto", fontsize: "14px", color: "#282828", textAlign: "center" }}>
                                            <div class="col-lg-12 row">
                                                <div class="col-lg-6">
                                                    <img src={Edit} alt={"Edit"}></img>
                                                </div>
                                                <div class="col-lg-6">
                                                    <img src={Close} alt={"Close"}  onClick={(e) => this.deleteUser(e, item)}></img>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div> */}
            </div>
        );
    }
}
export default AddUser;