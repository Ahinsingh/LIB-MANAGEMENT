import React, { Component } from 'react'
import { Redirect } from 'react-router'
import Cookies from 'universal-cookie'
import * as Constants from './Constants';

class BodyContent extends Component {

    constructor(props) {
        super(props);

        const cookies = new Cookies();
        this.state = {
            currentUser: cookies.get("user")
        };
    } 
    
    render(props) {
        if (this.state.currentUser) {
           
        }
        
        return (                
            <Redirect to="/login" />
        );
    }
}

export default BodyContent;