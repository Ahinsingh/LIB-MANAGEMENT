import React, { Component } from 'react'
import { Redirect } from 'react-router-dom'
import Cookies from 'universal-cookie'
import axios from 'axios'
import CryptoJS from 'crypto-js'
import Moment from 'moment'

import * as Constants from './Constants'
import LoadingSpinner from './LoadingSpinner'

class Login extends Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: false, redirect: false, staff: null,
            userName: '', password: '',
            userId:0
        };
    }

    async login(event) {
        if (event) {
            event.preventDefault();
        }

        this.setState({
            loading: true
        })

        //let password = CryptoJS.SHA256(this.state.password, 'eswjc123');
        let authenticationRequest = {
            "userName": this.state.userName,
            "password": this.state.password
        }
        let result = await axios.post(Constants.API + "authenticate", {
            "userName": this.state.userName,
            "password": this.state.password
        })
            .then(response => {
                if (response.data.token) {
                   
                    localStorage.setItem("token", JSON.stringify(response.data.token));
                } else {
                    alert("ID/Password do not match");
                    this.setState({
                        loading: false
                    })
                }
                return response.data;
            });
        // let result = await axios.get(Constants.API+"/");

        const token = JSON.parse(localStorage.getItem('token'));
        if (token) {
            const AuthStr = 'Bearer ' + token;
            console.log(AuthStr);
            let user = await axios.get(Constants.API + "v1/api/usermgmt/getUserDetails/" + this.state.userName, { 'headers': { 'Authorization': AuthStr } });
            localStorage.setItem("userId", user.data.userId);
            localStorage.setItem("userName", user.data.userName);
            localStorage.setItem("role", user.data.role);

            if(user.data.role!="ADMIN"){
                alert("You don't have access to this Site.Please login as ADMIN");
                localStorage.clear();
            }else{
               this.renderRedirect();
            }

            console.log(user.data);
            this.setState({
                loading: false
            })
        }
        console.log(result.data);
    }

    renderRedirect = () => {
          <Redirect to="/admin" />
    }

    handleChangeStaffid(event) {
        event.preventDefault();
        this.setState({
            // staffName: event.target.value.toLowerCase()
            userName: event.target.value
        })
    }

    handleChangePassword(event) {
        event.preventDefault();
        this.setState({
            password: event.target.value
        })
    }

    render() {
        return (
            <div style={{ textAlign: "center", backgroundColor: "#e8ecf4", paddingTop: "170px" }}>
                {this.renderRedirect()}
                <div >
                    <form>
                        <div >
                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>User Name *</label>&nbsp;
                            <div className="">
                                <input style={{ height: "30px", width: "220px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px" }} type="text" value={this.state.userName} onChange={(e) => this.handleChangeStaffid(e)} required />
                            </div>
                        </div>
                        <div >
                            <label style={{ fontFamily: "roboto", fontSize: "16px", color: "#282828" }}>Password *</label>&nbsp;
                            <div className="">
                                <input style={{ height: "30px", width: "220px", borderColor: "#d6d6d6", backgroundColor: "#fafafa", borderRadius: "2px" }} type="password" value={this.state.password} onChange={(e) => this.handleChangePassword(e)} required />
                            </div>
                        </div>
                        <br></br>
                        <div className="" >
                            <button style={{ height: "30px", backgroundColor: "#002c70", borderRadius: "4px", color: "#ffffff", fontFamily: "roboto", fontSize: "14px" }} onClick={(e) => this.login(e)}>Login </button>
                        </div>
                    </form>

                </div>
            </div>
        );
    }
}

export default Login;