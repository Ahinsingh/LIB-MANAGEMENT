  
    import React from 'react'
    import Modal from 'react-modal'
    import * as Constants from "./Constants"

    Modal.setAppElement('#root')
    
    const LoadingSpinner = () => (
        <Modal isOpen={true}
            style={Constants.CUSTOM_STYLES} >

            <div>
                <i className="fa fa-spinner fa-spin" /> Loading...
            </div>
        </Modal>
    );

    export default LoadingSpinner;
  
