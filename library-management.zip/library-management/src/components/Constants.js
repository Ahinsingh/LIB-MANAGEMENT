class Constants {
    
}


export const CUSTOM_STYLES = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      minWidth              : '20%'
    }
};

export const API = "http://localhost:8080/";


export const HIGHTLIGHT_JOB_CELL = {
  3: "alert-success"
};

export default Constants;