import React, { Component } from 'react'
import logo from '../src/Icons/logo.png'
import hamburger from '../src/Icons/hamburger.png'
import logout from '../src/Icons/logout.png'
import user from '../src/Icons/user.png'

class Header extends Component {
    constructor(props) {
        super(props)

        this.state = {
            role: localStorage.getItem('role')
        }
    }

    render() {
        return (
            <div style={{ backgroundColor: "#002c70", height: "70px" }}>
                <div class="col-xs-12 col-sm-12 col-lg-12 row">
                    <div class="col-xs-6 col-sm-6 col-lg-6">
                        <img src={hamburger} alt={"hamburger"}></img>
                        
                    </div>
                    <div class="col-xs-6 col-sm-6 col-lg-6">
                        <div class="col-xs-12 col-sm-12 col-lg-12 row">
                            <div class="col-xs-6 col-sm-6 col-lg-6">
                            </div>
                            <div class="col-xs-4 col-sm-4 col-lg-4">
                                <label style={{ fontFamily: "roboto", fontSize: "14px", color: "#ffffff", paddingTop: "19px", paddingLeft: "63px" }}>ADMIN</label>
                            </div>
                            <div class="col-xs-1 col-sm-1 col-lg-1">
                                <img src={user} alt={"user"} style={{ paddingTop: "19px" }}></img>
                            </div>
                            <div class="col-xs-1 col-sm-1 col-lg-1">
                                <img src={logout} alt={"logout"} style={{ paddingLeft: "25px", paddingTop: "19px" }} ></img>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Header
